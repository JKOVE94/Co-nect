package db.dto;

public class JobDTO {
	private int job_pk_num;
	private String job_name;
	
	public int getJob_pk_num() {
		return job_pk_num;
	}
	public void setJob_pk_num(int job_pk_num) {
		this.job_pk_num = job_pk_num;
	}
	public String getJob_name() {
		return job_name;
	}
	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}
}
